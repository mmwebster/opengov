Project Title: OpenGov
Members: Milo Webster, David Krieger, Daniel Hildebrandt, Anthony Awaida
Date: 7/4/2017